from setuptools import setup, find_packages

setup(
	name='gosuapi',
	version='1.1',
	author='Ian Oliveros',
	author_email='ioliveros.dev@gmail.com',
	packages=find_packages()
)
