# gosuapi

An Experimental GosuGamers API for Dota2 Section
